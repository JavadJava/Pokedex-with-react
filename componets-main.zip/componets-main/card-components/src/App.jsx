import React from 'react'
import Cards from './assets/components/cards'

export default function App() {
  return (
    <div>
      <Cards/>
    </div>
  )
}
