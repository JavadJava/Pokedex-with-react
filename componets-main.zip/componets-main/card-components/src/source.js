const data = [
    {
      id: 0,
      title:
        "سرفیس لپ تاپ استودیو ۲ با ۶۴ گیگابایت رم، پردازنده نسل ۱۳ و گرافیک 4060 از راه می‌رسد",
      image:
        "https://api2.zoomit.ir/media/2022-1-microsoft-surface-laptop-studio-watching-movie-638bb69a30170ea02c15b4ba?w=500&q=75",
    },
    {
      id: 1,
      title:
        "افشای جزئیاتی از گلکسی تب S9 ؛ نخستین تبلت پرچم‌دار مقاوم در برابر آب",
      image:
        "https://api2.zoomit.ir/media/2022-7-samsung-galaxy-tab-s8-plus-beside-s8-638c694b8615ae71282b1963?w=500&q=75",
    },
    {
      id: 2,
      title:
        "نبرد حقوقی خرید اکتیویژن احتمالاً سال‌ها طول می‌کشد و شاید باعث جداشدن بلیزارد شود",
      image:
        "https://api2.zoomit.ir/media/activision-blizzard-63f75446a7147ca4e87d2a2f?w=500&q=75",
    },
    {
      id: 3,
      title:
        "ارائه‌ موتور جستجو به‌سبک ChatGPT، هزینه‌های گوگل و مایکروسافت را ۱۰ برابر افزایش می‌دهد",
      image:
        "https://api2.zoomit.ir/media/google-bard-ai-63f73028a7147ca4e87d2a0f?w=500&q=75",
    },
    {
      id: 4,
      title:
        "گوشی اقتصادی نوکیا C02 با باتری قابل‌تعویض و اندروید ۱۲ گو رونمایی شد",
      image:
        "https://api2.zoomit.ir/media/nokia-c02-front-back-orange-background-63f858b3a7147ca4e87d2b41?w=250&q=75",
    },
    {
      id: 5,
      title:
        "گوشی اقتصادی نوکیا C02 با باتری قابل‌تعویض و اندروید ۱۲ گو رونمایی شد",
      image:
        "https://www.zoomit.ir/shutter/402772-handmade-wand-pencils-and-journals-for-wizards/",
    },
    {
      id: 6,
      title: "«قرمز تیره» احتمالاً رنگ ویژه آیفون ۱۵ پرو خواهد بود",
      image:
        "https://api2.zoomit.ir/media/dark-red-iphone-15-pro-leaked-render-one-63f84aa2a7147ca4e87d2b1f?w=250&q=75",
    },
    {
      id: 7,
      title:
        "مدل جدید Xperia 5 با ۱۶ گیگابایت رم و پردازنده Snapdragon 8 Gen 2 رؤیت شد",
      image:
        "https://api2.zoomit.ir/media/2022-9-sony-xperia-5-iv-front-view-in-hand-638bb86f8b369136d458d5b4?w=250&q=75",
    },
    {
      id: 8,
      title:
        "تولید پردازنده‌های نسل ۱۵ اینتل به تأخیر افتاد؟ (به‌روزرسانی: واکنش مدیرعامل اینتل)",
      image:
        "https://api2.zoomit.ir/media/2020-7-cee98807-1725-4f80-ab98-3c33783e2cbe-638bb0978b369136d4584aba?w=250&q=75",
    },
   ];
export default data